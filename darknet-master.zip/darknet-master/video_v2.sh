

./darknet detector demo ./cfg/coco.data ./cfg/yolov2.cfg ./yolov2.weights test50.mp4 -i 0 -thresh 0.25



